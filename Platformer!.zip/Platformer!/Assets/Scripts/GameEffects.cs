﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameEffects : MonoBehaviour {
	
	public Vector3 Spawnpoint;
	public float VoidHeight;
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position.y < VoidHeight) {
			SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);		}
	}
	
	void OnCollisionEnter (Collision other) {
		if (other.gameObject.tag == "Death") {
			SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
		}
	}
}
