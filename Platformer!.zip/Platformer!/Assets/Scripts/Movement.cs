﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {
	
	public Rigidbody rb;
	public BoxCollider bc;
	public Camera playerCamera;
	public float OriginalFOV;
	public float ZoomIn;
	public float moveSpeed;
	public float jumpPower;
	public float gameSpeed;
	public float GroundDetetectionHeight;
	public float JumpPadPower;
	public float OriginalJumpPower;
	public float SlowMotionSpeed;
	public float OriginalMoveSpeed;
	private float DistToGround;
	
	[SerializeField] private LayerMask PlatformLayerMask;
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();
		DistToGround = bc.bounds.extents.y;
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 movement = new Vector3(-gameSpeed, 0, (Input.GetAxis("Horizontal") * moveSpeed));
		transform.position += movement * Time.deltaTime;
		
		if (Input.GetButtonDown("Jump")) { //Checks if already jumping
			Jump();
		}
		if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow)){
			SlowMotion();
			ZoomInDist();
		}
		if (Input.GetKeyUp(KeyCode.S) || Input.GetKeyUp(KeyCode.DownArrow)){
			NormalSpeed();
			OriginalFOVDist();
		}
	}
	
	void Jump() {
		if (Physics.Raycast(transform.position, -Vector3.up, DistToGround + GroundDetetectionHeight)) {
			gameObject.GetComponent<Rigidbody>().AddForce(new Vector3(0f, jumpPower, 0f), ForceMode.Impulse);
		}
		
			Debug.Log(Physics.Raycast(transform.position, -Vector3.up, DistToGround + GroundDetetectionHeight));
	}
	void OnCollisionEnter(Collision other){
		if (other.gameObject.tag == "JumpPad"){
			jumpPower = JumpPadPower;
			
		}
	}
	void OnCollisionExit(Collision other){
		if(other.gameObject.tag == "JumpPad"){
			jumpPower = OriginalJumpPower;
		}
	}
	void SlowMotion(){
		gameSpeed = SlowMotionSpeed;
	}
	void NormalSpeed(){
		gameSpeed = OriginalMoveSpeed;
	}
	void ZoomInDist(){
		playerCamera.fieldOfView = ZoomIn;
	}	
	void OriginalFOVDist(){
		playerCamera.fieldOfView = OriginalFOV;
	}
}
