﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleMovement : MonoBehaviour {
	public Rigidbody rb;
	public float moveSpeed;
	public float DistTravel;
	Vector3 position1;
	Vector3 position2;
	Vector3 position3;
	Vector3 position4;
	public int target;
	

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();
		position1 = new Vector3(transform.position.x, transform.position.y, transform.position.z + DistTravel);
		position2 = new Vector3(transform.position.x, transform.position.y, transform.position.z - DistTravel);
		position3 = new Vector3(transform.position.x, transform.position.y + DistTravel, transform.position.z);
		position4 = new Vector3(transform.position.x, transform.position.y - DistTravel, transform.position.z);
	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position == position1) {
			target = 2;
		}
		if (transform.position == position2) {
			target = 1;
		}
		if (target == 1) {
			transform.position = Vector3.MoveTowards(transform.position, position1, moveSpeed * Time.deltaTime);
		}
		if (target == 2) {
			transform.position = Vector3.MoveTowards(transform.position, position2, moveSpeed * Time.deltaTime);
		}
		if (transform.position == position3) {
			target = 4;
		}
		if (transform.position == position4) {
			target = 3;
		}
		if (target == 3) {
			transform.position = Vector3.MoveTowards(transform.position, position3, moveSpeed * Time.deltaTime);
		}
		if (target == 4) {
			transform.position = Vector3.MoveTowards(transform.position, position4, moveSpeed * Time.deltaTime);
		}
	}
} 
